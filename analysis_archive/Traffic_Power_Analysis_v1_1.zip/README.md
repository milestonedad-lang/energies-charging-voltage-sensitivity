# 交通—电力：等电量映射补充结果包 v1.1

先阅读 outputs/交通电力_等电量映射补充报告_v1_1.md，再查看 outputs/映射敏感性汇总_v1_1.csv。本包是补充分析，不是投稿成稿。

## 原主分析与本轮的区别

source/交通电力_正式结果与复现包_v1.zip为原v1完整原包，字节不变。里面报告“等电量替代映射尚未完成”的表述对应当时状态；本轮最新状态以v1.1补充报告为准。此次并未替换或修改原v1文件。

补充方案在原结果已知后制定，在本轮新增潮流计算前内部锁定；不得写作原始主分析的预注册。只补充两条馈线×20映射×两种等电量输入，共80个新增场景、347520场景—小时。原A/B输出按哈希验证后复用。映射0结果单独保留，不与20种替代映射混合统计。

## 可直接读取的结果

- results/*B-G.npz及*B-Z.npz：80份新增逐小时结果，4344小时/份，用numpy.load(allow_pickle=False)读取。
- results/all_mapping_paired_comparisons.csv：120个完整配对比较，包括原A/B及新增A/B-G、A/B-Z。原A/B参照仅复用，不计入新增计算。
- results/new_scenarios.csv：新增场景收敛、残差、电压与网损摘要。
- results/threshold_and_flag_sensitivity.csv：0.90/0.94/0.95下限及排除31完整小时的等电量敏感性，共320行。
- results/fixed_mapping_0_reference.csv：固定映射0原结果，独立展示。
- evidence/：补充方案、执行前代码与来源记录、80例独立数值校验、执行概要、保存输出一致性。
- outputs/：中文结论报告、20映射统计汇总。

## 完整复算

与v1同环境：Python3.12，numpy2.3.5、pandas2.2.3、scipy1.17.0；具体版本见evidence/setup_before_new_voltage.json。解压本包后在根目录执行：

```bash
python code/restore_base.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python code/run_addendum.py
python code/check_saved_results.py
python code/build_report.py
```

恢复程序解开原包并调用原包输入恢复程序，下载两个指定提交的官方网架数据文件、核对哈希；该步骤需联网。无需MATLAB。没有网络也可直接读取本包新增结果和内含原包中的A/B结果。

不要在复算时重新运行lock_addendum.py；该脚本仅用于记录本次新增计算前的锁定过程，已有方案保留原样。复算会改写本地输出和执行时间，建议另解压副本；浮点末位可能随平台改变。本包不依赖外部QA或Library操作代码即可复算。

SHA256SUMS.json涵盖本包各成员（不含清单本身）。source中的原包有自己的完整清单及原始来源、许可说明。原始数据的许可不因本包而改变。

## 解释范围

统计最小值/中位数/最大值是20种合成映射的情景摘要，不是抽样置信区间。0不一致率表示两组二元判断相同，不代表没有越限或电压相等。输入均不是真实计量；没有真实城市电网连接、实测能量或热容量额定值，不报告数据精度排名、真实城市风险或完整承载力。
